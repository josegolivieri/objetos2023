/**
 * Calculadora
 */
public class Calculadora {
    /**
     * método que suma
     * @param num1
     * @param num2
     */
    public void sumar(int num1, int num2){
        System.out.println(num1+num2);
    }

    /**
     * método que resta
     * @param num1
     * @param num2
     */
    public void restar(int num1, int num2){
        //TODO hacer restar
    }

    /**
     * método que multiplica
     * @param num1
     * @param num2
     */
    public void multiplicar(int num1, int num2){
        //TODO hacer multiplicar
    }

    /**
     * método que dividir
     * @param num1
     * @param num2
     */
    public void dividir(int num1, int num2){
        //TODO hacer dividir
    }
}
