/**
 * 	Clase principal del proyecto!
 * 	@author carlos
 */
public class Hola {
	/**
	 * método principal del clase, punto de entrada!
	 * @param args argumentos que ingresan de consola
	 */
	public static void main(String[] args) {
		System.out.println("Hola Mundo!");

		// en consola java -version verificamos la versión runtime
		// javac -version verificamos la versión del compilador

		// Comentarios de una sola sola linea
		// El usuario final no puede ver este comentario

		/*
		 * Bloque
		 * de
		 * comentarios
		 * El usuario final no puede ver este comentario
		 */

		// TODO tarea pendiente

		/**
		 * Comentario JAVA DOC.
		 * El usuario final puede ver este comentario.
		 * Este comentario, debe colocarse delante de la declaración
		 * de método o clase.
		 */

		//Lenguajes de tipado fuerte:	C C++ C# java visualbasic typescript
		
		//Lenguajes de tipado debil:	php javascript python


		/*
		 * 	Memoria RAM:		Volatil				Costo alto			Veloz
		 * 
		 * 	Disco Duro:			Persistente			Costo bajo			Lento
		 * 
		 */

		
		int a; 		//Declaración de variable
		a=2;		//Asignación de valor//Declaración de variable
		System.out.println(a);

		int b=4;	//Declaración y asignación de valor
		System.out.println(b);

		int c=a+b;	//6
		System.out.println(c);

		//declaración y asignación multiple
		int d=8, e=65, f=35, g=46;

		//Una variable solo puede tener una declaración, 
		//pero puede tener infinitas asignaciones de valor.

		//int a=5;		//Error variable ya declarada
		a=65;
		a=72;
		a=8;
		System.out.println(a);

		//Tipo de datos enteros

		//Tipo de datos boolean				1 byte
		boolean bo=true;					// 1
		System.out.println(bo);				// true
		bo=false;							// 0
		System.out.println(bo);

		/*
		 * 		boolean bo=true;
		 * 
		 *      10000000
		 * 	    --------
		 */

		//Tipo de datos byte (signed)				1 byte
		byte by=100;
		System.out.println(by);		//100

		/*
		 * 		byte by=100;
		 * 
		 * 
		 * 		|--------|--------|
		 *    -128		 0 		 127
		 * 
		 * 		byteU by=100;			//Java no tiene tipos primitivos unsigned
		 * 
		 * 		|-----------------|
		 * 		0				 255
		 * 
		 */






	}
}
