public class Clase03 {
    public static void main(String[] args) {
        // Recorrido de un String
        String texto = "Esto es una cadena de texto!, me gustan los ñoquis, lindo día!!!";
        System.out.println(texto);

        char[] texto2={'h','o','l','a'};
        char[] texto3=new char[4];
        texto3[0]='h';
        texto3[1]='o';
        texto3[2]='l';
        texto3[3]='a';

        // Recorrido de vector texto3
        for(int i=0; i<texto3.length; i++){
            System.out.print(texto3[i]);
        }
        System.out.println();

        // Recorrido de vector de variable texto
        for (int i = 0; i < texto.length(); i++) {
            System.out.print(texto.charAt(i));
            // código indentado
        }
        System.out.println();

        // Recorrer el vector en mayusculas.
        for(int i=0; i<texto.length(); i++){
            char car=texto.charAt(i);
            if(car>=97 && car<=122) car-=32;        //car=car-32;
            System.out.print((char)car);
        }
        System.out.println();

        //Operador Ternario ?
        for(int i=0; i<texto.length(); i++){
            char car=texto.charAt(i);
            System.out.print((car>=97 && car<=122)?(car-=32):car);
        }
        System.out.println();

        // Recorrer el vector en minusculas.
        for(int i=0; i<texto.length(); i++){
            char car=texto.charAt(i);
            System.out.print((car>=65 && car<=90)?(car+=32):car);
        }
        System.out.println();

        System.out.println(texto.toLowerCase());
        System.out.println(texto.toUpperCase());

        //tema pendiente Vector args.


        /*
         * Paradigma de Objetos
         * 
         * Clases:  Las clases representan todo lo sustantivo y se
         *      detectan como sustantivos.
         * Ej: Auto, Alumno, SillaClase03
         * 
         * Las clases en java son objetos de la clase java.lang.Class
         * 
         * 
         * Que es un atributo? Un atributo describe a la clase (adjetivos),
         * son variables contenidas dentro de una clase, los atributos
         * tienen un tipo de datos definidos.
         * Los atributos tienen un proceso de inicialización automática
         * los atributos numericos se inicializan en 0
         * los atributos String se inicializan en null;
         * 
         * Los atributos en java son objetos de la clase 
         * java.lang.reflect.Field
         * 
         * Que es un método? Un método es una acción que realiza la clase.
         * se lo detecta como verbo Ej: cantar(), reir(), llorar(), pagar()
         * 
         * En un método pueden existir párametros de entrada o salida.
         * 
         * Los métodos en java son objetos de la clase
         * java.lang.reflect.Method
         * 
         * 
         * Que es un objeto? Un objeto es una una instancia de la clase
         * y representa una situación en particular, tiene estado 
         * propio.
         * El estado de un objeto es el valor de sus atributos.
         * Un objeto se crea a partir de una clase y se una
         * la palabra clave de lenguage new
         */

        System.out.println("-- auto1 --");
        Auto auto1=new Auto();      //new construye un objeto
        auto1.marca="Fiat";
        auto1.modelo="Idea";
        auto1.color="Gris";
        auto1.acelerar();           // 10
        auto1.acelerar();           // 20
        auto1.acelerar();           // 30
        auto1.frenar();             // 20

        System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);

        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Ka";
        auto2.color="Azul";

        for(int a=0; a<=60; a++){
            auto2.acelerar();
        }

        System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);


    }
    
}