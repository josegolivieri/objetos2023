public class Programa {

    //Atributos
    static int atributo1;
    static String atributo2;

    public static void main(String[] args) {
        //punto de entrada del proyecto

        //String[] args argumentos que se ingresan desde consola.
        System.out.println("Longitud de vector args[]: "+args.length);
        for(int i=0; i<args.length; i++){
            System.out.println(args[i]);
        }

        int variable1;
        String variable2;
        System.out.println(atributo1);  //Se inicializa en cero
        System.out.println(atributo2);  //Se inicializa en null
        //System.out.println(variable1);
        //System.out.println(variable2);



    }
}
