//declaración de clase
public class Auto {
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //métodos
    void acelerar(){
        velocidad+=10;      //velocidad=velocidad+10;
        if(velocidad>=100) velocidad=100;
    }

    void frenar(){  
        velocidad-=10;      //velocidad=velocidad-10;
    }

}//end class Auto
